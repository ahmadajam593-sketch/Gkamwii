package com.hakawi.app.ui

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay

@Composable
fun HakawiRoot(vm: AppViewModel) {
    val ctx = LocalContext.current
    val profile by vm.profile.collectAsStateWithLifecycle()
    val items by vm.storeItems.collectAsStateWithLifecycle()
    val phase by vm.phase.collectAsStateWithLifecycle()
    val themeId = profile?.themeItem
    val palette = remember(themeId, items) { paletteFrom(items.firstOrNull { it.id == themeId }?.payload) }

    LaunchedEffect(Unit) { vm.toasts.collect { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() } }

    HakawiTheme(palette) {
        // Arabic interface: right-to-left everywhere.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(Modifier.fillMaxSize().background(palette.bg).systemBarsPadding().imePadding()) {
                when (phase) {
                    Phase.LOADING -> BootScreen(vm)
                    Phase.NEEDS_CONFIG -> SetupScreen()
                    Phase.SIGNED_OUT -> AuthScreen(vm)
                    Phase.BANNED -> BannedScreen(vm)
                    Phase.SIGNED_IN -> if (profile?.isAdmin == true) AdminRoot(vm) else UserRoot(vm)
                }
            }
        }
    }
}

/** Keeps data fresh: refresh when the app is visible and then every 30 seconds. */
@Composable
fun LiveSync(vm: AppViewModel) {
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            vm.onForeground()
            while (true) {
                delay(30_000)
                vm.refreshAll()
            }
        }
    }
}

@Composable
fun UserRoot(vm: AppViewModel) {
    val stack by vm.stack.collectAsStateWithLifecycle()
    val tab by vm.tab.collectAsStateWithLifecycle()
    val deep by vm.deepLinkStory.collectAsStateWithLifecycle()

    LiveSync(vm)
    LaunchedEffect(deep) {
        deep?.let {
            vm.openStoryFromLink(it)
            vm.deepLinkStory.value = null
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    BackHandler(enabled = stack.size > 1 || tab != UserTab.HOME) { vm.back() }

    val top = stack.last()
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            AnimatedContent(
                targetState = top,
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                label = "nav",
            ) { s ->
                when (s) {
                    is Screen.Tabs -> TabsContent(vm, tab)
                    is Screen.StoryPage -> StoryScreen(vm, s.id)
                    is Screen.Ledger -> LedgerScreen(vm)
                    is Screen.YouTube -> YouTubeScreen(vm, s.query)
                    else -> Box(Modifier.fillMaxSize())
                }
            }
        }
        if (top is Screen.Tabs) {
            MiniPlayerBar(vm)
            UserBottomBar(vm, tab)
        }
    }
}

@Composable
private fun TabsContent(vm: AppViewModel, tab: UserTab) {
    when (tab) {
        UserTab.HOME -> HomeScreen(vm)
        UserTab.SEARCH -> SearchScreen(vm)
        UserTab.LIBRARY -> LibraryScreen(vm)
        UserTab.STORE -> StoreScreen(vm)
        UserTab.ACCOUNT -> AccountScreen(vm)
    }
}

private data class TabSpec(val tab: UserTab, val label: String, val icon: ImageVector)

@Composable
private fun UserBottomBar(vm: AppViewModel, current: UserTab) {
    val scheme = MaterialTheme.colorScheme
    val specs = listOf(
        TabSpec(UserTab.HOME, "الرئيسية", Icons.Rounded.Home),
        TabSpec(UserTab.SEARCH, "البحث", Icons.Rounded.Search),
        TabSpec(UserTab.LIBRARY, "مكتبتي", Icons.Rounded.LibraryBooks),
        TabSpec(UserTab.STORE, "المتجر", Icons.Rounded.Storefront),
        TabSpec(UserTab.ACCOUNT, "حسابي", Icons.Rounded.Person),
    )
    NavigationBar(containerColor = scheme.surface) {
        specs.forEach { s ->
            NavigationBarItem(
                selected = current == s.tab,
                onClick = { vm.tab.value = s.tab },
                icon = { Icon(s.icon, contentDescription = s.label) },
                label = { Text(s.label, fontSize = 11.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black, selectedTextColor = scheme.secondary,
                    indicatorColor = scheme.secondary,
                    unselectedIconColor = MutedText, unselectedTextColor = MutedText,
                ),
            )
        }
    }
}

@Composable
fun MiniPlayerBar(vm: AppViewModel) {
    val state by vm.player.state.collectAsStateWithLifecycle()
    val position by vm.player.positionFlow.collectAsStateWithLifecycle(initialValue = 0L)
    val id = state.currentId ?: return
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp))
            .background(scheme.surface).clickable { vm.openStory(id) },
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            CoverImage(state.cover, Modifier.size(44.dp), corner = 10.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(state.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(state.narrator, color = MutedText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = { vm.player.seekBy(-15_000) }) {
                Icon(Icons.Rounded.Replay10, "رجوع 10 ثواني", tint = Color.White)
            }
            IconButton(onClick = { vm.player.togglePlayPause() }) {
                if (state.buffering && !state.playing) {
                    CircularProgressIndicator(Modifier.size(24.dp), color = scheme.secondary, strokeWidth = 2.dp)
                } else {
                    Icon(if (state.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "تشغيل/إيقاف", tint = scheme.secondary, modifier = Modifier.size(32.dp))
                }
            }
        }
        LinearProgressIndicator(
            progress = { if (state.durationMs > 0) (position.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(3.dp),
            color = scheme.secondary, trackColor = Color.Transparent,
        )
    }
}
