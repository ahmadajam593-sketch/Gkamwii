package com.hakawi.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** All server operations. Every sensitive action (points, purchases, views) goes through server functions. */
class Repo(private val api: SupabaseApi, private val session: SessionStore) {

    val configured: Boolean get() = api.configured
    val hasSession: Boolean get() = session.isSignedIn
    val currentUserId: String? get() = session.userId

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------------- Auth ----------------
    suspend fun signUp(email: String, password: String, name: String) {
        val data = JSONObject().put("display_name", name)
        api.authPost("signup", JSONObject().put("email", email).put("password", password).put("data", data))
    }

    suspend fun resendSignup(email: String) {
        api.authPost("resend", JSONObject().put("type", "signup").put("email", email))
    }

    suspend fun verifySignup(email: String, code: String) {
        val r = api.authPost("verify", JSONObject().put("type", "signup").put("email", email).put("token", code))
        session.save(r)
    }

    suspend fun signIn(email: String, password: String) {
        val r = api.authPost("token?grant_type=password", JSONObject().put("email", email).put("password", password))
        session.save(r)
    }

    suspend fun requestReset(email: String) {
        api.authPost("recover", JSONObject().put("email", email))
    }

    /** Verifies the emailed code, then sets the new password. */
    suspend fun resetPassword(email: String, code: String, newPassword: String) {
        val r = api.authPost("verify", JSONObject().put("type", "recovery").put("email", email).put("token", code))
        val token = r.str("access_token") ?: throw ApiException(400, "invalid token")
        api.authPut("user", JSONObject().put("password", newPassword), token)
        session.clear()
    }

    suspend fun signOut() {
        try { api.authPostSession("logout", JSONObject()) } catch (e: Exception) { /* offline: clear locally anyway */ }
        session.clear()
    }

    fun clearSession() = session.clear()

    suspend fun registerInstall() {
        if (session.installRegistered) return
        api.rpc("register_install", JSONObject().put("p_device", session.deviceId), useSession = false)
        session.installRegistered = true
    }

    // ---------------- Profile ----------------
    suspend fun fetchProfile(): Profile {
        val uid = session.userId ?: throw ApiException(401, "not signed in")
        val rows = parseArray(api.get("profiles?id=eq.$uid&select=*"))
        return rows.firstOrNull()?.toProfile() ?: throw ApiException(404, "profile missing")
    }

    suspend fun touchLastSeen() { api.rpc("touch_last_seen") }

    suspend fun updateName(name: String) {
        val uid = session.userId ?: return
        api.patch("profiles?id=eq.$uid", JSONObject().put("display_name", name).toString())
    }

    // ---------------- Stories ----------------
    suspend fun fetchStories(): List<Story> {
        val text = api.get("stories?select=*,categories(name)&order=created_at.desc&limit=1000")
        session.cachedStories = text
        return parseArray(text).map { it.toStory() }
    }

    fun cachedStories(): List<Story> = try {
        session.cachedStories?.let { t -> parseArray(t).map { it.toStory() } } ?: emptyList()
    } catch (e: Exception) { emptyList() }

    suspend fun fetchStory(id: String): Story? =
        parseArray(api.get("stories?id=eq.$id&select=*,categories(name)")).firstOrNull()?.toStory()

    suspend fun fetchCategories(): List<Category> =
        parseArray(api.get("categories?select=*&order=sort.asc,name.asc")).map { it.toCategory() }

    suspend fun fetchFavorites(): Set<String> =
        parseArray(api.get("favorites?select=story_id")).mapNotNull { it.str("story_id") }.toSet()

    suspend fun addFavorite(storyId: String) {
        api.post("favorites?on_conflict=user_id,story_id", JSONObject().put("story_id", storyId).toString(),
            "resolution=ignore-duplicates,return=minimal")
    }

    suspend fun removeFavorite(storyId: String) { api.delete("favorites?story_id=eq.$storyId") }

    suspend fun fetchProgress(): List<ProgressEntry> =
        parseArray(api.get("playback_progress?select=story_id,position_ms,updated_at&order=updated_at.desc&limit=100"))
            .map { ProgressEntry(it.str("story_id") ?: "", it.longOr("position_ms"), it.str("updated_at") ?: "") }

    suspend fun saveProgress(storyId: String, positionMs: Long) {
        val body = JSONObject().put("story_id", storyId).put("position_ms", positionMs)
            .put("updated_at", isoNow()).toString()
        api.post("playback_progress?on_conflict=user_id,story_id", body, "resolution=merge-duplicates,return=minimal")
    }

    suspend fun registerView(storyId: String) { api.rpc("register_view", JSONObject().put("p_story", storyId)) }

    suspend fun reportWatch(storyId: String, seconds: Int): WatchResult =
        parseObject(api.rpc("report_watch", JSONObject().put("p_story", storyId).put("p_seconds", seconds))).toWatchResult()

    // ---------------- Points & store ----------------
    suspend fun fetchLedger(): List<LedgerEntry> =
        parseArray(api.get("points_ledger?select=*&order=created_at.desc&limit=100")).map { it.toLedger() }

    suspend fun fetchStore(): List<StoreItem> =
        parseArray(api.get("store_items?select=*&order=sort.asc,created_at.asc")).map { it.toStoreItem() }

    suspend fun fetchOwned(): Set<String> {
        val uid = session.userId ?: return emptySet()
        return parseArray(api.get("purchases?user_id=eq.$uid&select=item_id")).mapNotNull { it.str("item_id") }.toSet()
    }

    suspend fun purchase(itemId: String): Int =
        parseObject(api.rpc("purchase_item", JSONObject().put("p_item", itemId))).intOr("balance")

    suspend fun equip(kind: String, itemId: String?) {
        val args = JSONObject().put("p_kind", kind).put("p_item", itemId ?: JSONObject.NULL)
        api.rpc("equip_cosmetic", args)
    }

    suspend fun fetchRewardConfig(): RewardConfig {
        val row = parseArray(api.get("app_settings?key=eq.reward&select=value")).firstOrNull() ?: return RewardConfig.DEFAULT
        val v = row.optJSONObject("value") ?: return RewardConfig.DEFAULT
        return RewardConfig(
            minDurationSec = v.intOr("min_duration_sec", 600), points = v.intOr("points", 5),
            minWatchRatio = v.optDouble("min_watch_ratio", 0.9), dailyCap = v.intOr("daily_cap", 50),
        )
    }

    // ---------------- Ads ----------------
    suspend fun fetchAds(): List<Ad> =
        parseArray(api.get("ads?select=*&active=eq.true&order=created_at.desc")).map { it.toAd() }

    suspend fun registerAdView(adId: String) { api.rpc("register_ad_view", JSONObject().put("p_ad", adId)) }

    // ---------------- Admin ----------------
    suspend fun adminStats(): AdminStats = parseObject(api.rpc("admin_stats")).toStats()

    suspend fun adminAllAds(): List<Ad> =
        parseArray(api.get("ads?select=*&order=created_at.desc")).map { it.toAd() }

    suspend fun adminAllStoreItems(): List<StoreItem> = fetchStore()

    /** Creates (id == null) or updates a row. Row-level security rejects anyone who is not an admin. */
    suspend fun adminSave(table: String, id: String?, body: JSONObject) {
        if (id == null) api.post(table, body.toString(), "return=minimal")
        else api.patch("$table?id=eq.$id", body.toString())
    }

    suspend fun adminDelete(table: String, id: String) { api.delete("$table?id=eq.$id") }

    suspend fun adminSearchUsers(query: String): List<AdminUser> {
        val q = query.trim()
        val filter = if (q.isEmpty()) "" else "&email=ilike.*${enc(q)}*"
        return parseArray(api.get("profiles?select=*&order=created_at.desc&limit=40$filter")).map { it.toAdminUser() }
    }

    suspend fun adminAdjustPoints(userId: String, amount: Int, note: String): Int =
        api.rpc("admin_adjust_points", JSONObject().put("p_user", userId).put("p_amount", amount).put("p_note", note))
            .trim().toIntOrNull() ?: 0

    suspend fun adminSetBan(userId: String, banned: Boolean) {
        api.rpc("admin_set_ban", JSONObject().put("p_user", userId).put("p_banned", banned))
    }

    suspend fun adminSaveReward(c: RewardConfig) {
        val value = JSONObject().put("min_duration_sec", c.minDurationSec).put("points", c.points)
            .put("min_watch_ratio", c.minWatchRatio).put("daily_cap", c.dailyCap)
        val body = JSONObject().put("key", "reward").put("value", value).toString()
        api.post("app_settings?on_conflict=key", body, "resolution=merge-duplicates,return=minimal")
    }

    suspend fun upload(
        folder: String, extension: String, mime: String, size: Long,
        input: () -> java.io.InputStream, onProgress: (Float) -> Unit,
    ): String {
        val safeExt = extension.lowercase().filter { it.isLetterOrDigit() }.ifEmpty { "bin" }
        val path = "$folder/${java.util.UUID.randomUUID()}.$safeExt"
        return api.upload("hakawi", path, mime, size, input, onProgress)
    }

    private fun isoNow(): String {
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        return f.format(java.util.Date())
    }
}
