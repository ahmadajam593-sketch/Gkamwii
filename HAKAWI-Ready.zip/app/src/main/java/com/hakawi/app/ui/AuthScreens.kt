package com.hakawi.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun LogoBadge(size: Dp = 88.dp) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.3f))
            .background(Brush.linearGradient(listOf(scheme.bg(), scheme.primary))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.AutoStories, null, tint = scheme.secondary, modifier = Modifier.size(size * 0.55f))
    }
}

private fun ColorScheme.bg(): Color = this.background

@Composable
fun BrandHeader() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        LogoBadge()
        Spacer(Modifier.height(12.dp))
        Text("HAKAWI", color = MaterialTheme.colorScheme.secondary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
        Text("حكاوي", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("قصص صوتية ومرئية تشبهك", color = MutedText, fontSize = 13.sp)
    }
}

@Composable
fun BootScreen(vm: AppViewModel) {
    val error by vm.bootError.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        BrandHeader()
        Spacer(Modifier.height(28.dp))
        if (error == null) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.secondary)
        } else {
            MessageBox(error ?: "", "إعادة المحاولة") { vm.start() }
            SoftButton("تسجيل الخروج", onClick = { vm.signOut() })
        }
    }
}

@Composable
fun SetupScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        BrandHeader()
        Spacer(Modifier.height(24.dp))
        MessageBox(
            "هذه النسخة من التطبيق لم تُربط بقاعدة البيانات السحابية بعد.\n\n" +
                "أضف السرّين SUPABASE_URL و SUPABASE_ANON_KEY في GitHub (Settings → Secrets and variables → Actions) " +
                "ثم أعد تشغيل البناء. الخطوات الكاملة موجودة في ملف README.md.",
        )
    }
}

@Composable
fun BannedScreen(vm: AppViewModel) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.Block, null, tint = Color(0xFFFCA5A5), modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("تم حظر هذا الحساب", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("تواصل مع إدارة التطبيق إذا كنت تعتقد أن ذلك حدث بالخطأ.", color = MutedText, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        SoftButton("تسجيل الخروج", onClick = { vm.signOut() })
    }
}

@Composable
fun AuthScreen(vm: AppViewModel) {
    val step by vm.authStep.collectAsStateWithLifecycle()
    val busy by vm.authBusy.collectAsStateWithLifecycle()
    val error by vm.authError.collectAsStateWithLifecycle()
    val info by vm.authInfo.collectAsStateWithLifecycle()
    val pending by vm.pendingEmail.collectAsStateWithLifecycle()

    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var newPass by rememberSaveable { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(16.dp))
        BrandHeader()
        Spacer(Modifier.height(24.dp))
        Text(
            when (step) {
                AuthStep.LOGIN -> "مرحباً بعودتك"
                AuthStep.SIGNUP -> "إنشاء حساب جديد"
                AuthStep.VERIFY -> "تأكيد البريد الإلكتروني"
                AuthStep.FORGOT -> "استعادة كلمة المرور"
                AuthStep.RESET -> "كلمة مرور جديدة"
            },
            color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(14.dp))

        info?.let { InfoBanner(it, false) }
        error?.let { InfoBanner(it, true) }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (step) {
                AuthStep.LOGIN -> {
                    HField("البريد الإلكتروني", email, { email = it }, keyboard = KeyboardType.Email)
                    HField("كلمة المرور", password, { password = it }, password = true)
                    PrimaryButton("تسجيل الدخول", { vm.submitLogin(email, password) }, busy = busy)
                    TextButton(onClick = { vm.setAuthStep(AuthStep.FORGOT) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("نسيت كلمة المرور؟", color = MutedText)
                    }
                    SoftButton("إنشاء حساب جديد", { vm.setAuthStep(AuthStep.SIGNUP) }, Modifier.fillMaxWidth())
                }
                AuthStep.SIGNUP -> {
                    HField("الاسم", name, { name = it })
                    HField("البريد الإلكتروني", email, { email = it }, keyboard = KeyboardType.Email)
                    HField("كلمة المرور (6 أحرف على الأقل)", password, { password = it }, password = true)
                    PrimaryButton("إنشاء الحساب", { vm.submitSignUp(email, password, name) }, busy = busy)
                    TextButton(onClick = { vm.setAuthStep(AuthStep.LOGIN) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("لدي حساب بالفعل", color = MutedText)
                    }
                }
                AuthStep.VERIFY -> {
                    Text("أدخل الرمز المرسل إلى: $pending", color = MutedText, fontSize = 13.sp)
                    HField("رمز التحقق", code, { code = it.filter { c -> c.isLetterOrDigit() } }, keyboard = KeyboardType.Number)
                    PrimaryButton("تأكيد وتفعيل الحساب", { vm.submitVerify(code) }, busy = busy)
                    SoftButton("إعادة إرسال الرمز", { vm.resendCode() }, Modifier.fillMaxWidth())
                    TextButton(onClick = { vm.setAuthStep(AuthStep.LOGIN) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("رجوع لتسجيل الدخول", color = MutedText)
                    }
                }
                AuthStep.FORGOT -> {
                    Text("سنرسل رمز استعادة إلى بريدك الإلكتروني", color = MutedText, fontSize = 13.sp)
                    HField("البريد الإلكتروني", email, { email = it }, keyboard = KeyboardType.Email)
                    PrimaryButton("إرسال الرمز", { vm.submitForgot(email) }, busy = busy)
                    TextButton(onClick = { vm.setAuthStep(AuthStep.LOGIN) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("رجوع", color = MutedText)
                    }
                }
                AuthStep.RESET -> {
                    Text("أدخل الرمز المرسل إلى: $pending", color = MutedText, fontSize = 13.sp)
                    HField("رمز الاستعادة", code, { code = it.filter { c -> c.isLetterOrDigit() } }, keyboard = KeyboardType.Number)
                    HField("كلمة المرور الجديدة", newPass, { newPass = it }, password = true)
                    PrimaryButton("تغيير كلمة المرور", { vm.submitReset(code, newPass) }, busy = busy)
                    TextButton(onClick = { vm.setAuthStep(AuthStep.LOGIN) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("رجوع", color = MutedText)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun InfoBanner(text: String, isError: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(12.dp))
            .background(if (isError) Color(0x33EF4444) else Color(0x3322C55E)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (isError) Icons.Rounded.ErrorOutline else Icons.Rounded.CheckCircle, null,
            tint = if (isError) Color(0xFFFCA5A5) else Color(0xFF86EFAC), modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontSize = 13.sp, lineHeight = 20.sp)
    }
}
