package com.hakawi.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.hakawi.app.BuildConfig
import com.hakawi.app.data.Ad
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun StoryScreen(vm: AppViewModel, storyId: String) {
    val ctx = LocalContext.current
    val stories by vm.stories.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val state by vm.player.state.collectAsStateWithLifecycle()
    val controller by vm.player.controller.collectAsStateWithLifecycle()
    val position by vm.player.positionFlow.collectAsStateWithLifecycle(initialValue = 0L)
    val reward by vm.reward.collectAsStateWithLifecycle()
    var ad by remember { mutableStateOf<Ad?>(null) }
    var dragPos by remember { mutableStateOf<Float?>(null) }
    val scheme = MaterialTheme.colorScheme

    val story = stories.firstOrNull { it.id == storyId }
    if (story == null) {
        Column(Modifier.fillMaxSize()) {
            TopBar("القصة", onBack = { vm.back() })
            MessageBox("هذه القصة لم تعد متاحة")
        }
        return
    }

    val isCurrent = state.currentId == story.id
    val isFav = story.id in favorites
    val resumeMs = vm.resumePositionMs(story.id)
    val eligible = story.rewardEligible && story.mediaType != "link" && story.durationSec >= reward.minDurationSec

    val onPlay: () -> Unit = {
        if (!story.isPlayable) {
            vm.openExternal(story.mediaUrl)
        } else if (isCurrent) {
            vm.player.togglePlayPause()
        } else {
            val a = vm.adToShow()
            if (a != null) {
                vm.player.pause()
                vm.markAdShown(a)
                ad = a
            } else {
                vm.startPlayback(story)
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            TopBar(story.categoryName ?: "القصة", onBack = { vm.back() }) {
                IconButton(onClick = {
                    val base = BuildConfig.SHARE_BASE_URL
                    val link = if (base.isNotBlank()) "$base/?story=${story.id}" else "hakawi://story/${story.id}"
                    val text = "استمع إلى «${story.title}» على تطبيق حكاوي\n$link"
                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                    ctx.startActivity(Intent.createChooser(send, "مشاركة القصة"))
                }) { Icon(Icons.Rounded.Share, "مشاركة", tint = Color.White) }
                IconButton(onClick = { vm.toggleFavorite(story.id) }) {
                    Icon(
                        if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "المفضلة",
                        tint = if (isFav) Color(0xFFF472B6) else Color.White,
                    )
                }
            }

            if (story.isVideo && isCurrent && controller != null) {
                AndroidView(
                    factory = { c -> PlayerView(c).apply { useController = false } },
                    update = { it.player = controller },
                    onRelease = { it.player = null },
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(20.dp)).background(Color.Black),
                )
            } else {
                CoverImage(
                    story.coverUrl,
                    Modifier.padding(horizontal = if (story.isVideo) 16.dp else 48.dp).fillMaxWidth()
                        .aspectRatio(if (story.isVideo) 16f / 9f else 1f),
                    corner = 24.dp,
                )
            }

            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(story.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                Text(story.narrator.ifBlank { "راوي غير محدد" }, color = scheme.secondary, fontSize = 15.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(formatDuration(story.durationSec))
                    Pill(if (story.isVideo) "فيديو" else "صوتي")
                    Pill("${story.views} مشاهدة")
                }
                if (eligible) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "🎁 شاهد القصة كاملة لتحصل على ${reward.points} نقاط",
                        color = scheme.secondary, fontSize = 13.sp, textAlign = TextAlign.Center,
                    )
                }
            }

            // Player controls
            if (isCurrent) {
                val dur = state.durationMs.coerceAtLeast(1L).toFloat()
                Column(Modifier.padding(horizontal = 20.dp)) {
                    Slider(
                        value = (dragPos ?: position.toFloat()).coerceIn(0f, dur),
                        onValueChange = { dragPos = it },
                        onValueChangeFinished = {
                            dragPos?.let { vm.player.seekTo(it.toLong()) }
                            dragPos = null
                        },
                        valueRange = 0f..dur,
                        colors = SliderDefaults.colors(thumbColor = scheme.secondary, activeTrackColor = scheme.secondary, inactiveTrackColor = scheme.outline),
                    )
                    Row(Modifier.fillMaxWidth()) {
                        Text(formatMs((dragPos ?: position.toFloat()).toLong()), color = MutedText, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(formatMs(state.durationMs), color = MutedText, fontSize = 12.sp)
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { vm.player.seekBy(-15_000) }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.Replay10, "رجوع", tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    Spacer(Modifier.width(16.dp))
                    Box(
                        Modifier.size(72.dp).clip(CircleShape).background(scheme.secondary).clickable(onClick = onPlay),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (state.buffering && !state.playing) {
                            CircularProgressIndicator(Modifier.size(30.dp), color = Color.Black, strokeWidth = 3.dp)
                        } else {
                            Icon(if (state.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "تشغيل/إيقاف", tint = Color.Black, modifier = Modifier.size(42.dp))
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    IconButton(onClick = { vm.player.seekBy(15_000) }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.Forward10, "تقديم", tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                }
            } else {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    PrimaryButton(
                        when {
                            !story.isPlayable -> "فتح الرابط"
                            resumeMs > 5_000L -> "متابعة من ${formatMs(resumeMs)}"
                            else -> "تشغيل القصة"
                        },
                        onPlay,
                    )
                }
            }

            if (story.description.isNotBlank()) {
                FormSection("عن القصة") {
                    Text(story.description, color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp, lineHeight = 23.sp)
                }
            }
        }

        ad?.let { current ->
            AdOverlay(current, vm) {
                ad = null
                vm.startPlayback(story)
            }
        }
    }
}

/** Full-screen ad published by the admin. Skippable / duration rules come from the ad itself. */
@OptIn(UnstableApi::class)
@Composable
fun AdOverlay(ad: Ad, vm: AppViewModel, onFinished: () -> Unit) {
    val ctx = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    var elapsed by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val finish = {
        if (!finished) {
            finished = true
            onFinished()
        }
    }
    val total = ad.durationSec.coerceAtLeast(3)

    LaunchedEffect(ad.id) {
        while (elapsed < total) {
            delay(1000)
            elapsed++
        }
        finish()
    }

    val isVideo = ad.mediaType == "video" && !ad.mediaUrl.isNullOrBlank()
    val exo = remember(ad.id) { if (isVideo) ExoPlayer.Builder(ctx).build() else null }
    DisposableEffect(ad.id) {
        val p = exo
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) finish()
            }
        }
        if (p != null) {
            p.addListener(listener)
            p.setMediaItem(MediaItem.fromUri(Uri.parse(ad.mediaUrl.orEmpty())))
            p.prepare()
            p.playWhenReady = true
        }
        onDispose {
            p?.removeListener(listener)
            p?.release()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).clickable(enabled = false) { }) {
        if (isVideo && exo != null) {
            AndroidView(
                factory = { c -> PlayerView(c).apply { useController = false } },
                update = { it.player = exo },
                onRelease = { it.player = null },
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            val img = ad.imageUrl ?: ad.mediaUrl
            if (!img.isNullOrBlank()) {
                AsyncImage(model = img, contentDescription = ad.title, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else {
                Text(ad.title, color = Color.White, fontSize = 24.sp, modifier = Modifier.align(Alignment.Center))
            }
        }

        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text("إعلان", color = scheme.secondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.weight(1f))
            if (ad.skippable) {
                val wait = (ad.skipAfterSec - elapsed).coerceAtLeast(0)
                Box(
                    Modifier.clip(RoundedCornerShape(10.dp))
                        .background(if (wait == 0) scheme.secondary else Color.Black.copy(alpha = 0.6f))
                        .clickable(enabled = wait == 0) { finish() }.padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Text(
                        if (wait == 0) "تخطي الإعلان" else "تخطي بعد $wait ث",
                        color = if (wait == 0) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    )
                }
            } else {
                Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text("تبدأ القصة بعد ${(total - elapsed).coerceAtLeast(0)} ث", color = Color.White, fontSize = 13.sp)
                }
            }
        }

        if (!ad.linkUrl.isNullOrBlank()) {
            Box(Modifier.align(Alignment.BottomCenter).padding(24.dp)) {
                PrimaryButton("زيارة الإعلان", { vm.openExternal(ad.linkUrl) })
            }
        }
        LinearProgressIndicator(
            progress = { (elapsed.toFloat() / total).coerceIn(0f, 1f) },
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
            color = scheme.secondary, trackColor = Color.Transparent,
        )
    }
}
