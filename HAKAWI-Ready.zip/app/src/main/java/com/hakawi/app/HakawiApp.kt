package com.hakawi.app

import android.app.Application
import com.hakawi.app.data.Repo
import com.hakawi.app.data.SessionStore
import com.hakawi.app.data.SupabaseApi

class HakawiApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

class AppContainer(app: Application) {
    val session = SessionStore(app)
    val api = SupabaseApi(session)
    val repo = Repo(api, session)
}
