package com.hakawi.app

import android.app.Application
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.hakawi.app.notify.AnnouncementWorker
import com.hakawi.app.notify.Notifier
import java.util.concurrent.TimeUnit
import com.hakawi.app.data.Repo
import com.hakawi.app.data.SessionStore
import com.hakawi.app.data.SupabaseApi

class HakawiApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Notifier.createChannel(this)
        val request = PeriodicWorkRequestBuilder<AnnouncementWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("hakawi-announcements", ExistingPeriodicWorkPolicy.KEEP, request)
    }
}

class AppContainer(app: Application) {
    val session = SessionStore(app)
    val api = SupabaseApi(session)
    val repo = Repo(api, session)
    val channels = com.hakawi.app.data.ChannelFeed(app)
}
