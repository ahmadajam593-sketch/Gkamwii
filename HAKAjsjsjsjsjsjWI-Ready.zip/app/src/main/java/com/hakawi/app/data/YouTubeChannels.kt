package com.hakawi.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class ChannelInfo(val handle: String)
data class ChannelVideo(val id: String, val title: String, val published: String)
data class ChannelData(val name: String, val videos: List<ChannelVideo>)

object Channels {
    /** The narrators whose stories are featured in the app. */
    val all = listOf(ChannelInfo("vwar"), ChannelInfo("abulsadiq"), ChannelInfo("walid.q"), ChannelInfo("badr3"))
    fun pageUrl(handle: String) = "https://m.youtube.com/@$handle/videos"
}

/**
 * Reads a channel's latest videos from YouTube's public RSS feed (an official, key-less feature).
 * Videos are played through the normal YouTube website inside the app. Nothing is downloaded.
 */
class ChannelFeed(context: Context) {
    private val prefs = context.getSharedPreferences("hakawi_channels", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).build()

    private fun get(url: String): String {
        val req = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
            .header("Accept-Language", "ar,en;q=0.8")
            .header("Cookie", "CONSENT=YES+1; SOCS=CAI")
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiException(r.code, "HTTP ${r.code}")
            return r.body?.string() ?: ""
        }
    }

    private fun resolveId(handle: String): String {
        prefs.getString("id_$handle", null)?.let { return it }
        val html = get("https://www.youtube.com/@$handle")
        val patterns = listOf(
            Regex("""rel="canonical" href="https://www\.youtube\.com/channel/(UC[A-Za-z0-9_-]{22})"""),
            Regex(""""externalId":"(UC[A-Za-z0-9_-]{22})""""),
            Regex(""""browseId":"(UC[A-Za-z0-9_-]{22})""""),
            Regex("""channel_id=(UC[A-Za-z0-9_-]{22})"""),
        )
        for (p in patterns) {
            val id = p.find(html)?.groupValues?.get(1)
            if (id != null) {
                prefs.edit().putString("id_$handle", id).apply()
                return id
            }
        }
        throw ApiException(404, "channel not found")
    }

    private fun tag(s: String, name: String): String? =
        Regex("<$name>(.*?)</$name>", RegexOption.DOT_MATCHES_ALL).find(s)?.groupValues?.get(1)?.let { unescape(it.trim()) }

    private fun unescape(s: String) = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")

    suspend fun load(handle: String): ChannelData = withContext(Dispatchers.IO) {
        val id = resolveId(handle)
        val xml = get("https://www.youtube.com/feeds/videos.xml?channel_id=$id")
        val name = tag(xml.substringBefore("<entry>"), "title") ?: handle
        val videos = Regex("<entry>(.*?)</entry>", RegexOption.DOT_MATCHES_ALL).findAll(xml).mapNotNull { m ->
            val e = m.groupValues[1]
            val vid = tag(e, "yt:videoId") ?: return@mapNotNull null
            ChannelVideo(vid, tag(e, "title") ?: "", (tag(e, "published") ?: "").take(10))
        }.toList()
        ChannelData(name, videos)
    }
}
