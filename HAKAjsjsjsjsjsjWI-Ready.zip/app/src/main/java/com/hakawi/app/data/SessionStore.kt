package com.hakawi.app.data

import android.content.Context
import org.json.JSONObject
import java.util.UUID

/** Keeps the login session in the app's private storage. */
class SessionStore(context: Context) {
    private val p = context.getSharedPreferences("hakawi_session", Context.MODE_PRIVATE)

    val accessToken: String? get() = p.getString("at", null)
    val refreshToken: String? get() = p.getString("rt", null)
    val expiresAtMs: Long get() = p.getLong("exp", 0L)
    val userId: String? get() = p.getString("uid", null)
    val email: String? get() = p.getString("email", null)
    val isSignedIn: Boolean get() = !accessToken.isNullOrBlank()

    fun save(json: JSONObject) {
        val at = json.str("access_token") ?: return
        val expiresIn = json.intOr("expires_in", 3600)
        val user = json.optJSONObject("user")
        p.edit()
            .putString("at", at)
            .putString("rt", json.str("refresh_token") ?: refreshToken)
            .putLong("exp", System.currentTimeMillis() + expiresIn * 1000L)
            .putString("uid", user?.str("id") ?: userId)
            .putString("email", user?.str("email"))
            .apply()
    }

    fun clear() {
        p.edit().remove("at").remove("rt").remove("exp").remove("uid").remove("email").apply()
    }

    /** Keeps the guest session while an admin is signed in, so the guest account (points, favorites) comes back on exit. */
    fun stashGuest() {
        p.edit().putString("g_at", accessToken).putString("g_rt", refreshToken)
            .putLong("g_exp", expiresAtMs).putString("g_uid", userId).apply()
    }

    fun restoreGuest(): Boolean {
        val at = p.getString("g_at", null) ?: return false
        p.edit().putString("at", at).putString("rt", p.getString("g_rt", null))
            .putLong("exp", p.getLong("g_exp", 0L)).putString("uid", p.getString("g_uid", null))
            .remove("email").apply()
        return true
    }

    /** Anonymous id used only to count installs. */
    val deviceId: String
        get() {
            val existing = p.getString("device", null)
            if (existing != null) return existing
            val id = UUID.randomUUID().toString()
            p.edit().putString("device", id).apply()
            return id
        }

    var installRegistered: Boolean
        get() = p.getBoolean("install_reg", false)
        set(v) { p.edit().putBoolean("install_reg", v).apply() }

    var lastAdShownAt: Long
        get() = p.getLong("last_ad", 0L)
        set(v) { p.edit().putLong("last_ad", v).apply() }

    fun savePositionLocal(storyId: String, ms: Long) { p.edit().putLong("pos_$storyId", ms).apply() }
    fun positionLocal(storyId: String): Long = p.getLong("pos_$storyId", 0L)

    var termsAccepted: Boolean
        get() = p.getBoolean("terms_ok", false)
        set(v) { p.edit().putBoolean("terms_ok", v).apply() }

    var seenAnnouncementId: Long
        get() = p.getLong("ann_seen", 0L)
        set(v) { p.edit().putLong("ann_seen", v).apply() }

    var notifiedAnnouncementId: Long
        get() = p.getLong("ann_notified", 0L)
        set(v) { p.edit().putLong("ann_notified", v).apply() }

    var cachedStories: String?
        get() = p.getString("cache_stories", null)
        set(v) { p.edit().putString("cache_stories", v).apply() }
}
