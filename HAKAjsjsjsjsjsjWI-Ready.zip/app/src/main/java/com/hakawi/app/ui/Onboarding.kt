package com.hakawi.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

private data class IntroPage(val icon: ImageVector, val title: String, val text: String)

private val TERMS = listOf(
    "التطبيق مخصّص للاستماع والمشاهدة والتفاعل، ويُقدَّم كما هو.",
    "حسابك «حساب ضيف» محفوظ على جهازك، ولا نطلب منك بريداً إلكترونياً ولا كلمة مرور.",
    "أنت مسؤول عن أي قصة ترفعها، وتؤكد أنك تملك حقوقها أو أن نشرها مسموح. يُمنع رفع محتوى مسيء أو مخالف للدين أو القانون أو الآداب أو ينتهك حقوق الآخرين.",
    "تراجع الإدارة كل قصة قبل نشرها، ولها رفضها أو إخفاؤها أو حذفها في أي وقت.",
    "التعليقات بأدب واحترام. يُمنع السب والإساءة والإعلانات، وللإدارة حذف المخالف وحظر صاحبه.",
    "النقاط ليس لها قيمة نقدية، وللإدارة تعديلها أو إلغاؤها عند اكتشاف تلاعب.",
    "مقاطع يوتيوب تُعرض من موقع يوتيوب الرسمي وتخضع لشروطه، وحقوقها لأصحابها.",
    "نحفظ الحد الأدنى من البيانات اللازمة لتشغيل التطبيق: معرّف الحساب، الاسم، الصورة، التعليقات، المشاهدات.",
    "باستمرارك في استخدام التطبيق فأنت توافق على هذه الشروط، وقد نحدّثها من وقت لآخر.",
)

/** Shown once, the first time the app opens: short intro + terms the user must accept. */
@Composable
fun OnboardingScreen(vm: AppViewModel) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    var agreed by rememberSaveable { mutableStateOf(false) }
    val scheme = MaterialTheme.colorScheme
    val pages = listOf(
        IntroPage(Icons.Rounded.AutoStories, "أهلاً بك في حكاوي", "قصص صوتية ومرئية من رواة مميزين. استمع في أي وقت، وأكمل من حيث توقفت، حتى والتطبيق في الخلفية."),
        IntroPage(Icons.Rounded.Stars, "اجمع النقاط", "شاهد القصص الطويلة (10 دقائق فأكثر) كاملة لتحصل على نقاط، ثم استبدلها في المتجر بثيمات وإطارات ومزايا خاصة."),
        IntroPage(Icons.Rounded.Forum, "شارك وعلّق", "علّق على القصص، وأضف قصصك أنت، وشارك أي قصة مع أصدقائك برابط، وسيصلك إشعار عند نزول كل قصة جديدة."),
    )
    val last = pages.size // the terms page

    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        LogoBadge(72.dp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (0..last).forEach { i ->
                Box(
                    Modifier.size(width = if (i == step) 22.dp else 8.dp, height = 8.dp).clip(RoundedCornerShape(4.dp))
                        .background(if (i == step) scheme.secondary else Color.White.copy(alpha = 0.25f)),
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            if (step < last) {
                val p = pages[step]
                Spacer(Modifier.height(24.dp))
                Box(
                    Modifier.size(110.dp).clip(CircleShape).background(scheme.primary.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center,
                ) { Icon(p.icon, null, tint = scheme.secondary, modifier = Modifier.size(56.dp)) }
                Spacer(Modifier.height(24.dp))
                Text(p.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(p.text, color = MutedText, fontSize = 16.sp, lineHeight = 26.sp, textAlign = TextAlign.Center)
            } else {
                Text("الشروط والأحكام", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(scheme.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    TERMS.forEachIndexed { i, t ->
                        Text("${i + 1}. $t", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { agreed = !agreed }.padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(
                        checked = agreed, onCheckedChange = { agreed = it },
                        colors = CheckboxDefaults.colors(checkedColor = scheme.secondary, checkmarkColor = Color.Black, uncheckedColor = MutedText),
                    )
                    Text("أوافق على الشروط والأحكام", color = Color.White, fontSize = 15.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        if (step < last) {
            PrimaryButton("التالي", { step++ })
            TextButton(onClick = { step = last }) { Text("تخطي", color = MutedText) }
        } else {
            PrimaryButton("ابدأ الاستخدام", { vm.acceptTerms() }, enabled = agreed)
            if (step > 0) TextButton(onClick = { step = 0 }) { Text("عرض التعريف من البداية", color = MutedText) }
        }
    }
}
