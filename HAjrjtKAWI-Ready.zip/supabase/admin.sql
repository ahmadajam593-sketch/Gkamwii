-- Run by the GitHub workflow with:  psql -v admin_pw="$ADMIN_PASSWORD" -f supabase/admin.sql
-- The admin password is NOT stored in this repository: it comes from the ADMIN_PASSWORD secret.
create extension if not exists pgcrypto with schema extensions;

update auth.users
set encrypted_password = extensions.crypt(:'admin_pw', extensions.gen_salt('bf')),
    email_confirmed_at = coalesce(email_confirmed_at, now())
where lower(email) = 'admin@gmail.com';

insert into public.profiles (id, email, display_name)
select id, email, 'الأدمن' from auth.users where lower(email) = 'admin@gmail.com'
on conflict (id) do nothing;

update public.profiles set role = 'admin', display_name = 'الأدمن' where lower(email) = 'admin@gmail.com';

do $$
begin
  if not exists (select 1 from public.profiles where role = 'admin') then
    raise exception 'The admin account was not created. Check that "Allow new users to sign up" and Email provider are enabled in Supabase Auth.';
  end if;
end $$;
