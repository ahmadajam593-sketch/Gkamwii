package com.hakawi.app.data

import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.str(name: String): String? {
    if (!has(name) || isNull(name)) return null
    val v = optString(name).trim()
    return if (v.isEmpty() || v == "null") null else v
}

fun JSONObject.intOr(name: String, default: Int = 0): Int {
    if (!has(name) || isNull(name)) return default
    val d = optDouble(name)
    return if (d.isNaN()) default else d.toInt()
}

fun JSONObject.longOr(name: String, default: Long = 0L): Long {
    if (!has(name) || isNull(name)) return default
    val d = optDouble(name)
    return if (d.isNaN()) default else d.toLong()
}

fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }

fun parseArray(text: String): List<JSONObject> =
    if (text.isBlank()) emptyList() else JSONArray(text).objects()

fun parseObject(text: String): JSONObject = if (text.isBlank()) JSONObject() else JSONObject(text)
