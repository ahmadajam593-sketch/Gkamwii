package com.hakawi.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.json.JSONObject

/** "New story" messages and messages from the admin. */
@Composable
fun NotificationsScreen(vm: AppViewModel) {
    val list by vm.announcements.collectAsStateWithLifecycle()
    val seenId by vm.seenAnnouncementId.collectAsStateWithLifecycle()
    // remember which ones were unread when the screen opened, then mark everything as read
    val unreadAtOpen = remember { seenId }
    LaunchedEffect(list.size) { vm.markAnnouncementsRead() }

    Column(Modifier.fillMaxSize()) {
        TopBar("الإشعارات", onBack = { vm.back() })
        if (list.isEmpty()) {
            MessageBox("لا توجد رسائل بعد. سنخبرك فور نزول أي قصة جديدة 🔔")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(list, key = { it.id }) { a ->
                    val isNew = a.id > unreadAtOpen
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(if (isNew) MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface)
                            .clickable(enabled = a.storyId != null) { a.storyId?.let { vm.openStory(it) } }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.Notifications, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (a.body.isNotBlank()) Text(a.body, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            Text(a.createdAt.take(16).replace('T', ' '), color = MutedText, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

/** A visitor submits a story. It is saved as "pending" and the admin approves it. */
@Composable
fun UserStoryForm(vm: AppViewModel) {
    val categories by vm.categories.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    val saving by vm.saving.collectAsStateWithLifecycle()
    val progress by vm.uploadProgress.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("") }
    var narrator by remember { mutableStateOf(profile?.displayName ?: "") }
    var description by remember { mutableStateOf("") }
    var mediaType by remember { mutableStateOf("audio") }
    var mediaUrl by remember { mutableStateOf("") }
    var coverUrl by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("") }
    var categoryId by remember { mutableStateOf<String?>(null) }
    val openCategories = remember(categories) { categories.filter { !it.exclusive } }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.uploadFile(uri, "user") { r ->
            mediaUrl = r.url
            if (r.durationSec > 0) duration = r.durationSec.toString()
        }
    }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.uploadFile(uri, "user") { r -> coverUrl = r.url }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("ارفع قصتك", onBack = { vm.back() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "شارك قصتك مع الجميع. بعد إرسالها تراجعها الإدارة ثم تظهر لكل المستخدمين.",
                color = MutedText, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp),
            )
            FormSection("بيانات القصة") {
                HField("اسم القصة", title, { title = it })
                HField("اسم الراوي", narrator, { narrator = it })
                HField("وصف القصة", description, { description = it }, singleLine = false, minLines = 3)
            }
            if (openCategories.isNotEmpty()) {
                FormSection("التصنيف") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { Pill("بدون", selected = categoryId == null) { categoryId = null } }
                        items(openCategories, key = { it.id }) { c -> Pill(c.name, selected = categoryId == c.id) { categoryId = c.id } }
                    }
                }
            }
            FormSection("ملف القصة") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("صوتي", selected = mediaType == "audio") { mediaType = "audio" }
                    Pill("فيديو", selected = mediaType == "video") { mediaType = "video" }
                }
                SoftButton(
                    if (mediaType == "video") "اختر ملف فيديو" else "اختر ملف صوتي",
                    { mediaPicker.launch(if (mediaType == "video") "video/*" else "audio/*") },
                    Modifier.fillMaxWidth(), Icons.Rounded.UploadFile,
                )
                progress?.let {
                    LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.secondary)
                    Text("جارٍ الرفع... ${(it * 100).toInt()}%", color = MutedText, fontSize = 12.sp)
                }
                if (mediaUrl.isNotBlank()) Text("✔ تم رفع الملف", color = Color(0xFF86EFAC), fontSize = 13.sp)
                HField("المدة بالثواني", duration, { duration = it.filter { c -> c.isDigit() } }, keyboard = KeyboardType.Number)
            }
            FormSection("صورة الغلاف (اختياري)") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CoverImage(coverUrl.ifBlank { null }, Modifier.size(80.dp), corner = 14.dp)
                    SoftButton("اختر صورة", { coverPicker.launch("image/*") }, Modifier.weight(1f), Icons.Rounded.Image)
                }
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                PrimaryButton("إرسال للمراجعة", {
                    when {
                        title.isBlank() -> vm.toast("اكتب اسم القصة")
                        mediaUrl.isBlank() -> vm.toast("اختر ملف القصة أولاً")
                        else -> {
                            val body = JSONObject()
                                .put("title", title.trim())
                                .put("narrator", narrator.trim())
                                .put("description", description.trim())
                                .put("duration_sec", duration.toIntOrNull() ?: 0)
                                .put("media_type", mediaType)
                                .put("media_url", mediaUrl.trim())
                                .put("cover_url", if (coverUrl.isBlank()) JSONObject.NULL else coverUrl.trim())
                                .put("category_id", categoryId ?: JSONObject.NULL)
                                .put("status", "pending")
                            vm.submitUserStory(body) { vm.back() }
                        }
                    }
                }, busy = saving || progress != null)
            }
        }
    }
}

@Composable
fun CommentsSection(vm: AppViewModel, storyId: String) {
    val comments by vm.comments.collectAsStateWithLifecycle()
    val sending by vm.commentSending.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    var text by remember(storyId) { mutableStateOf("") }

    LaunchedEffect(storyId) {
        vm.loadComments(storyId)
        while (true) {
            kotlinx.coroutines.delay(15_000)
            vm.refreshComments(storyId)
        }
    }

    FormSection("التعليقات (${comments.size})") {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HField("اكتب تعليقك...", text, { text = it.take(500) }, Modifier.weight(1f))
            IconButton(
                onClick = { if (text.isNotBlank()) vm.postComment(storyId, text.trim()) { text = "" } },
                enabled = !sending,
            ) { Icon(Icons.Rounded.Send, "إرسال", tint = MaterialTheme.colorScheme.secondary) }
        }
        if (comments.isEmpty()) {
            Text("كن أول من يعلّق على هذه القصة 💬", color = MutedText, fontSize = 13.sp)
        }
        comments.forEach { c ->
            val mine = c.userId == profile?.id
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Avatar(c.author, null, 36.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.author, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(c.body, color = Color.White, fontSize = 14.sp, lineHeight = 21.sp)
                    Text(c.createdAt.take(16).replace('T', ' '), color = MutedText, fontSize = 10.sp)
                }
                if (mine) {
                    IconButton(onClick = { vm.deleteComment(c) }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.Delete, "حذف تعليقي", tint = Color(0xFFFCA5A5), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
