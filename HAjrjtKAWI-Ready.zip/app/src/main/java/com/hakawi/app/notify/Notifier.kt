package com.hakawi.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.hakawi.app.R
import com.hakawi.app.data.Announcement
import com.hakawi.app.ui.MainActivity

object Notifier {
    private const val CHANNEL = "hakawi_news"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "القصص الجديدة والرسائل", NotificationManager.IMPORTANCE_DEFAULT)
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    /** Shows a phone notification for a "new story" message. Tapping it opens the story. */
    fun show(ctx: Context, a: Announcement) {
        val manager = NotificationManagerCompat.from(ctx)
        if (!manager.areNotificationsEnabled()) return
        val uri = if (a.storyId != null) "hakawi://story/${a.storyId}" else "hakawi://home"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            .setClass(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, a.id.toInt(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(a.title)
            .setContentText(a.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(a.body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try {
            manager.notify(a.id.toInt(), n)
        } catch (e: SecurityException) {
            // notification permission not granted
        }
    }
}
