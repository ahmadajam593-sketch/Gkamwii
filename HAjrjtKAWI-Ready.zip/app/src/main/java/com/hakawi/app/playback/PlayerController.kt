package com.hakawi.app.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.hakawi.app.data.Story
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow

data class PlayerUi(
    val currentId: String? = null,
    val title: String = "",
    val narrator: String = "",
    val cover: String? = null,
    val playing: Boolean = false,
    val buffering: Boolean = false,
    val durationMs: Long = 0L,
)

/** App-side handle to the PlaybackService. */
class PlayerController(private val context: Context) {
    private var future: ListenableFuture<MediaController>? = null

    private val _controller = MutableStateFlow<MediaController?>(null)
    /** Used by the video surface (PlayerView). */
    val controller: StateFlow<MediaController?> = _controller.asStateFlow()

    private val _state = MutableStateFlow(PlayerUi())
    val state: StateFlow<PlayerUi> = _state.asStateFlow()

    /** Ticks only while collected by lifecycle-aware UI. */
    val positionFlow: Flow<Long> = flow {
        while (true) {
            emit(_controller.value?.currentPosition?.coerceAtLeast(0L) ?: 0L)
            delay(500)
        }
    }

    fun connect() {
        if (future != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val f = MediaController.Builder(context, token).buildAsync()
        future = f
        f.addListener({
            val c = try { f.get() } catch (e: Exception) { future = null; return@addListener }
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) { refresh(player) }
            })
            _controller.value = c
            refresh(c)
        }, ContextCompat.getMainExecutor(context))
    }

    private fun refresh(p: Player) {
        val item = p.currentMediaItem
        val md = item?.mediaMetadata
        val dur = p.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: md?.durationMs ?: 0L
        _state.value = PlayerUi(
            currentId = item?.mediaId,
            title = md?.title?.toString().orEmpty(),
            narrator = md?.artist?.toString().orEmpty(),
            cover = md?.artworkUri?.toString(),
            playing = p.isPlaying,
            buffering = p.playbackState == Player.STATE_BUFFERING,
            durationMs = dur,
        )
    }

    /** Returns false if the player service is not connected yet. */
    fun play(story: Story, startMs: Long, minRewardSec: Int): Boolean {
        val c = _controller.value ?: return false
        c.setMediaItem(story.toMediaItem(minRewardSec), startMs.coerceAtLeast(0L))
        c.prepare()
        c.play()
        return true
    }

    fun togglePlayPause() {
        val c = _controller.value ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
            c.play()
        }
    }

    fun pause() { _controller.value?.pause() }

    fun seekTo(ms: Long) { _controller.value?.seekTo(ms) }
    fun seekBy(deltaMs: Long) {
        val c = _controller.value ?: return
        val dur = if (c.duration == C.TIME_UNSET) Long.MAX_VALUE else c.duration
        c.seekTo((c.currentPosition + deltaMs).coerceIn(0L, dur))
    }

    fun stop() {
        _controller.value?.let { it.pause(); it.clearMediaItems() }
    }

    fun release() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        _controller.value = null
    }
}
