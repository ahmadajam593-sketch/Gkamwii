package com.hakawi.app.notify

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.hakawi.app.HakawiApp

/**
 * Runs about every 15 minutes (even when the app is closed) and shows a phone notification
 * for every new-story message published since the last check.
 */
class AnnouncementWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = (applicationContext as HakawiApp).container
        if (!c.api.configured || !c.session.isSignedIn) return Result.success()
        return try {
            val list = c.repo.fetchAnnouncements(10)
            val maxId = list.maxOfOrNull { it.id } ?: return Result.success()
            val last = c.session.notifiedAnnouncementId
            if (last == 0L) {
                c.session.notifiedAnnouncementId = maxId // first run: remember the current state only
                return Result.success()
            }
            list.filter { it.id > last }.sortedBy { it.id }.takeLast(3).forEach { Notifier.show(applicationContext, it) }
            if (maxId > last) c.session.notifiedAnnouncementId = maxId
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
