package com.hakawi.app.data

import com.hakawi.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit

class ApiException(val status: Int, message: String) : Exception(message)

/** Minimal Supabase client over plain HTTPS (Auth, PostgREST, Storage). No third-party SDK. */
class SupabaseApi(private val session: SessionStore) {
    private val base = BuildConfig.SUPABASE_URL
    private val anon = BuildConfig.SUPABASE_ANON_KEY
    val configured: Boolean get() = base.isNotBlank() && anon.isNotBlank()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val refreshMutex = Mutex()

    private fun builder(url: String, token: String): Request.Builder =
        Request.Builder().url(url)
            .header("apikey", anon)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")

    private fun errorFrom(code: Int, body: String): ApiException {
        val msg = try {
            val o = JSONObject(body)
            o.str("message") ?: o.str("msg") ?: o.str("error_description") ?: o.str("error") ?: "HTTP $code"
        } catch (e: Exception) {
            if (body.isNotBlank() && body.length < 200) body else "HTTP $code"
        }
        return ApiException(code, msg)
    }

    private suspend fun send(req: Request): Pair<Int, String> = withContext(Dispatchers.IO) {
        client.newCall(req).execute().use { r -> r.code to (r.body?.string() ?: "") }
    }

    /** Refreshes the access token when it is about to expire. */
    private suspend fun validToken(): String? {
        val token = session.accessToken ?: return null
        if (session.expiresAtMs - System.currentTimeMillis() < 60_000L && session.refreshToken != null) {
            refreshSession()
        }
        return session.accessToken ?: token
    }

    suspend fun refreshSession(): Boolean = refreshMutex.withLock { doRefresh() }

    private suspend fun doRefresh(): Boolean {
        val rt = session.refreshToken ?: return false
        return try {
            val body = JSONObject().put("refresh_token", rt).toString().toRequestBody(jsonType)
            val req = Request.Builder().url("$base/auth/v1/token?grant_type=refresh_token")
                .header("apikey", anon).post(body).build()
            val (code, resp) = send(req)
            if (code in 200..299) {
                session.save(JSONObject(resp))
                true
            } else {
                if (code == 400 || code == 401 || code == 403) session.clear()
                false
            }
        } catch (e: IOException) {
            false
        }
    }

    private suspend fun exec(useSession: Boolean, build: (String) -> Request): String {
        var token = (if (useSession) validToken() else null) ?: anon
        var retried = false
        while (true) {
            val (code, body) = send(build(token))
            if (code in 200..299) return body
            if (code == 401 && useSession && !retried && session.refreshToken != null) {
                retried = true
                if (refreshSession()) {
                    token = session.accessToken ?: anon
                    continue
                }
            }
            throw errorFrom(code, body)
        }
    }

    // ---------- PostgREST ----------
    suspend fun get(path: String): String = exec(true) { builder("$base/rest/v1/$path", it).get().build() }

    suspend fun post(path: String, body: String, prefer: String? = null): String = exec(true) { t ->
        val b = builder("$base/rest/v1/$path", t).post(body.toRequestBody(jsonType))
        if (prefer != null) b.header("Prefer", prefer)
        b.build()
    }

    suspend fun patch(path: String, body: String): String = exec(true) { t ->
        builder("$base/rest/v1/$path", t).header("Prefer", "return=representation")
            .patch(body.toRequestBody(jsonType)).build()
    }

    suspend fun delete(path: String): String = exec(true) { builder("$base/rest/v1/$path", it).delete().build() }

    suspend fun rpc(fn: String, args: JSONObject = JSONObject(), useSession: Boolean = true): String =
        exec(useSession) { builder("$base/rest/v1/rpc/$fn", it).post(args.toString().toRequestBody(jsonType)).build() }

    // ---------- Auth ----------
    private suspend fun authCall(method: String, path: String, body: JSONObject, bearer: String? = null): JSONObject {
        val b = builder("$base/auth/v1/$path", bearer ?: anon)
        val rb = body.toString().toRequestBody(jsonType)
        val req = if (method == "PUT") b.put(rb).build() else b.post(rb).build()
        val (code, resp) = send(req)
        if (code !in 200..299) throw errorFrom(code, resp)
        return parseObject(resp)
    }

    suspend fun authPost(path: String, body: JSONObject): JSONObject = authCall("POST", path, body)
    suspend fun authPostSession(path: String, body: JSONObject): JSONObject =
        authCall("POST", path, body, session.accessToken)
    suspend fun authPut(path: String, body: JSONObject, bearer: String): JSONObject =
        authCall("PUT", path, body, bearer)

    // ---------- Storage (admin only: enforced by storage policies) ----------
    suspend fun upload(
        bucket: String,
        objectPath: String,
        mime: String,
        size: Long,
        input: () -> InputStream,
        onProgress: (Float) -> Unit,
    ): String {
        val type = try { mime.toMediaType() } catch (e: Exception) { "application/octet-stream".toMediaType() }
        val body = object : RequestBody() {
            override fun contentType() = type
            override fun contentLength() = size
            override fun writeTo(sink: BufferedSink) {
                input().use { ins ->
                    val buf = ByteArray(64 * 1024)
                    var sent = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        sink.write(buf, 0, n)
                        sent += n
                        if (size > 0) onProgress((sent.toFloat() / size).coerceIn(0f, 1f))
                    }
                }
            }
        }
        exec(true) { t ->
            builder("$base/storage/v1/object/$bucket/$objectPath", t).header("x-upsert", "false").post(body).build()
        }
        return "$base/storage/v1/object/public/$bucket/$objectPath"
    }
}
