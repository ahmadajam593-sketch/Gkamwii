import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Cloud settings come from environment variables (GitHub Secrets). The anon key is a PUBLIC key by design:
// it is only safe because Row Level Security in supabase/schema.sql protects the data.
val supabaseUrl: String = (System.getenv("SUPABASE_URL") ?: "").trim().trimEnd('/')
val supabaseKey: String = (System.getenv("SUPABASE_ANON_KEY") ?: "").trim()
val shareBase: String = (System.getenv("SHARE_BASE_URL") ?: "").trim().trimEnd('/')
val shareHost: String = try {
    if (shareBase.isNotEmpty()) (URI(shareBase).host ?: "hakawi.invalid") else "hakawi.invalid"
} catch (e: Exception) {
    "hakawi.invalid"
}

android {
    namespace = "com.hakawi.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hakawi.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "SUPABASE_URL", "\"$supabaseUrl\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"$supabaseKey\"")
        buildConfigField("String", "SHARE_BASE_URL", "\"$shareBase\"")
        manifestPlaceholders["shareHost"] = shareHost
    }

    signingConfigs {
        create("release") {
            storeFile = file(System.getenv("KEYSTORE_PATH") ?: "../keystore/hakawi.jks")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "hakawi-ks-2026"
            keyAlias = System.getenv("KEY_ALIAS") ?: "hakawi"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "hakawi-ks-2026"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    lint { abortOnError = false; checkReleaseBuilds = false }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
